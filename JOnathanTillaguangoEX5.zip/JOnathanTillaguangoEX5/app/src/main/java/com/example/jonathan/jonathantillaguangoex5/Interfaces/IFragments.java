package com.example.jonathan.jonathantillaguangoex5.Interfaces;

import com.example.jonathan.jonathantillaguangoex5.Fragments.FrgListar;

public interface IFragments extends FrgListar.OnFragmentInteractionListener {
}
