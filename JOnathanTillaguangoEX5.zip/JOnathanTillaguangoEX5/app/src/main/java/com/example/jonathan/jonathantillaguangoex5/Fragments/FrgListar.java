package com.example.jonathan.jonathantillaguangoex5.Fragments;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;

import com.example.jonathan.jonathantillaguangoex5.Adaptador.Adapter;
import com.example.jonathan.jonathantillaguangoex5.Modelo.Wines;
import com.example.jonathan.jonathantillaguangoex5.R;
import com.example.jonathan.jonathantillaguangoex5.SW.ServicioWeb;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;

/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link FrgListar.OnFragmentInteractionListener} interface
 * to handle interaction events.
 * Use the {@link FrgListar#newInstance} factory method to
 * create an instance of this fragment.
 */
public class FrgListar extends Fragment implements AdapterView.OnItemClickListener {
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";
    // TODO: Rename and change types of parameters
    private Context contextGeneral = null;
    private String mParam1;
    private String mParam2;
    private OnFragmentInteractionListener mListener;
    //recursos
    String url = "http://seguimientomedico.com/licores/index.php/wines";
    ServicioWeb servicioWeb;
    List<Wines> listWine;
    List<Wines> listaWine2;
    ArrayList<Wines> arrayWine;
    ArrayList<Wines> item;
    ListView showWine;
    Wines wines;
    Adapter adaptador;
    public FrgListar() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment FrgListar.
     */
    // TODO: Rename and change types and number of parameters
    public static FrgListar newInstance(String param1, String param2) {
        FrgListar fragment = new FrgListar();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View vista = inflater.inflate(R.layout.fragment_frg_listar,container,false);
        showWine = vista.findViewById(R.id.ListWines);
        contextGeneral = this.getActivity();
        showListView();
        return vista;
    }
    private void showListView(){
        listWine = new ArrayList<Wines>();
        servicioWeb = new ServicioWeb();
        servicioWeb.execute(url,"1");
        try {
            String cadena = servicioWeb.get();
            cadena = cadena+'"'+"}]";
            JSONArray jsonArray= new JSONArray(cadena);
            //String resultadoJSON = jsonObject.getString("estado");
            //SI la respuesta del la iteraccion es 1 es decir Lectura del Objeto JSON
            //if(resultadoJSON.equals("1")){
               // JSONArray listaAlm = jsonObject.getJSONArray("alumnos");
                for(int i = 1; i < jsonArray.length(); i++){
                    Wines wineLector = new Wines();
                    wineLector.setId(Integer.parseInt(jsonArray.getJSONObject(i).getString("id")));
                    wineLector.setNombre(jsonArray.getJSONObject(i).getString("name"));
                    wineLector.setAño(Integer.parseInt(jsonArray.getJSONObject(i).getString("year")));
                    wineLector.setUvas(jsonArray.getJSONObject(i).getString("grapes"));
                    wineLector.setPais(jsonArray.getJSONObject(i).getString("country"));
                    wineLector.setRegion(jsonArray.getJSONObject(i).getString("region"));
                    wineLector.setDescripcion(jsonArray.getJSONObject(i).getString("description"));
                    wineLector.setImagen(jsonArray.getJSONObject(i).getString("picture"));
                    listWine.add(wineLector);
                }
                adaptador = new Adapter(contextGeneral,(ArrayList<Wines>) listWine);
                showWine.setAdapter(adaptador);
                adaptador.notifyDataSetChanged();

            //}
        } catch (ExecutionException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }

    }

    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        //dddddddddddddddd
    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Uri uri);
    }
}
